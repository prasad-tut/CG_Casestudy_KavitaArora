package com.cms.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	private static Connection connection=null;
	public static Connection getConnection() throws ClassNotFoundException, SQLException{
		//your code to create database connection 
		return connection;
	}
}
