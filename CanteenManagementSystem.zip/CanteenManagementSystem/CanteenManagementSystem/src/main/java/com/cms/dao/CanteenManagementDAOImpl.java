package com.cms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cms.db.DBConnection;
import com.cms.entity.Customer;
import com.cms.entity.Food;
import com.cms.entity.FoodOrder;
import com.cms.entity.Vendor;

public class CanteenManagementDAOImpl implements CanteenManagmentDAO{
	
	private List<Customer>customerList=new ArrayList<>();
	private List<Vendor>vendorList=new ArrayList<>();
	private List<Food>foodList=new ArrayList<>();
	private List<FoodOrder>foodOrderList=new ArrayList<>();
	private Connection connection=null;
	private PreparedStatement statement=null;
	private ResultSet resultSet=null;
	
	public CanteenManagementDAOImpl() {
		try {
			connection=DBConnection.getConnection();
		}catch(SQLException | ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	@Override
	public void addCustomer(){
		//your code here
		}

	@Override
	public void removeCustomer() {
		//your code here
		}

	@Override
	public void editCustomer() {
		//your code here
		
	}

	@Override
	public void searchCustomerById() {
		//your code here
	}

	@Override
	public void getAllCustomers() {
		//your code here
	}

	@Override
	public void addVendor() {
		//your code here
		
	}

	@Override
	public void removeVendor() {
		//your code here
		
	}

	@Override
	public void editVendor() {
		//your code here
		
	}

	@Override
	public void searchVendorById() {
		//your code here
		
	}

	@Override
	public void getAllVendors() {
		//your code here
		
	}

	@Override
	public void addFood() {
		//your code here
		
	}

	@Override
	public void removeFood() {
		//your code here
		
	}

	@Override
	public void editFood() {
		//your code here
		
	}

	@Override
	public void searchFoodById() {
		//your code here
		
	}

	@Override
	public void getAllFood() {
		//your code here
		
	}

	@Override
	public void placeOrder() {
		//your code here
		
	}

	@Override
	public void checkWalletBalance() {
		//your code here
		
	}

	@Override
	public void viewOrdersPlaced() {
		//your code here
		
	}

	@Override
	public void viewPendingOrders() {
		//your code here
		
	}

	@Override
	public void viewCompletedOrders() {
		//your code here
		
	}

	@Override
	public void cancelOrder() {
		//your code here
		
	}

	@Override
	public void completeOrder() {
		//your code here

	}

}